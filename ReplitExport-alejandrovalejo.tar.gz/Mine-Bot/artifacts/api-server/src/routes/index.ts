import { Router, type IRouter } from "express";
import healthRouter from "./health";
import botRouter from "./bot";
import inventoryRouter from "./inventory";

const router: IRouter = Router();

router.use(healthRouter);
router.use(botRouter);
router.use(inventoryRouter);

export default router;
