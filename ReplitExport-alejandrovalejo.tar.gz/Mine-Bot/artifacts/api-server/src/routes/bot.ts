import { Router, type IRouter } from "express";
import { botManager } from "../lib/bot-manager";
import {
  ConnectBotBody,
  SendChatBody,
  MoveBotBody,
  ExecuteCommandBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/bot/status", async (_req, res): Promise<void> => {
  res.json(botManager.getStatus());
});

router.post("/bot/connect", async (req, res): Promise<void> => {
  const parsed = ConnectBotBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { host, port, username, version, startupCommands, autoReconnect } = parsed.data;

  if (!host || !username) {
    res.status(400).json({ error: "host and username are required" });
    return;
  }

  try {
    const status = await botManager.connect({
      host,
      port: port ?? undefined,
      username,
      version: version ?? undefined,
      startupCommands: startupCommands ?? undefined,
      autoReconnect: autoReconnect ?? false,
    });
    res.json(status);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to connect";
    req.log.error({ err }, "Bot connect failed");
    res.status(400).json({ error: message });
  }
});

router.post("/bot/disconnect", async (_req, res): Promise<void> => {
  botManager.disconnect();
  res.json(botManager.getStatus());
});

router.post("/bot/chat", async (req, res): Promise<void> => {
  const parsed = SendChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    botManager.sendChat(parsed.data.message);
    res.json({ success: true, message: "Message sent" });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to send message";
    res.status(400).json({ error: message });
  }
});

router.post("/bot/move", async (req, res): Promise<void> => {
  const parsed = MoveBotBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    botManager.move(parsed.data.action, parsed.data.duration ?? undefined);
    res.json({ success: true, message: `Action ${parsed.data.action} started` });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to move";
    res.status(400).json({ error: message });
  }
});

router.get("/bot/chat-history", async (_req, res): Promise<void> => {
  res.json(botManager.getChatHistory());
});

router.post("/bot/command", async (req, res): Promise<void> => {
  const parsed = ExecuteCommandBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    botManager.executeCommand(parsed.data.command);
    res.json({ success: true, message: `Command executed` });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to execute command";
    res.status(400).json({ error: message });
  }
});

export default router;
