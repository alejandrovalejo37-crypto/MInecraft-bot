import { Router, type IRouter } from "express";
import { botManager } from "../lib/bot-manager";
import {
  EquipItemBody,
  DropItemBody,
  SelectHotbarBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/bot/inventory", async (_req, res): Promise<void> => {
  try {
    res.json(botManager.getInventory());
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to get inventory";
    res.status(400).json({ error: message });
  }
});

router.post("/bot/inventory/equip", async (req, res): Promise<void> => {
  const parsed = EquipItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await botManager.equipItem(parsed.data.slot, parsed.data.destination);
    res.json({ success: true, message: "Item equipped" });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to equip";
    res.status(400).json({ error: message });
  }
});

router.post("/bot/inventory/drop", async (req, res): Promise<void> => {
  const parsed = DropItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await botManager.dropItem(parsed.data.slot, parsed.data.count ?? undefined);
    res.json({ success: true, message: "Item dropped" });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to drop";
    res.status(400).json({ error: message });
  }
});

router.post("/bot/inventory/select", async (req, res): Promise<void> => {
  const parsed = SelectHotbarBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    botManager.selectHotbar(parsed.data.hotbarSlot);
    res.json({ success: true, message: `Selected hotbar slot ${parsed.data.hotbarSlot}` });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to select";
    res.status(400).json({ error: message });
  }
});

export default router;
