import mineflayer, { type Bot } from "mineflayer";
import { EventEmitter } from "events";
import { logger } from "./logger";

export interface ChatMessage {
  id: string;
  timestamp: string;
  text: string;
  source: "server" | "bot" | "player" | "system";
  username: string | null;
}

export interface BotPosition {
  x: number | null;
  y: number | null;
  z: number | null;
}

export interface BotStatus {
  connected: boolean;
  reconnecting: boolean;
  reconnectAttempts: number;
  username: string | null;
  host: string | null;
  port: number | null;
  health: number | null;
  food: number | null;
  position: BotPosition;
  gameMode: string | null;
  version: string | null;
  players: string[];
}

export interface BotConnectOptions {
  host: string;
  port?: number;
  username: string;
  version?: string;
  startupCommands?: string[];
  autoReconnect?: boolean;
}

const MAX_CHAT_HISTORY = 200;
const RECONNECT_DELAY_MS = 5000;
const MAX_RECONNECT_ATTEMPTS = 20;

class BotManager extends EventEmitter {
  private bot: Bot | null = null;
  private chatHistory: ChatMessage[] = [];
  private connectOptions: BotConnectOptions | null = null;
  private movementInterval: ReturnType<typeof setInterval> | null = null;
  private currentAction: string | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private _reconnecting = false;
  private _reconnectAttempts = 0;
  private manualDisconnect = false;

  getStatus(): BotStatus {
    if (!this.bot && !this._reconnecting) {
      return {
        connected: false,
        reconnecting: false,
        reconnectAttempts: this._reconnectAttempts,
        username: this.connectOptions?.username ?? null,
        host: this.connectOptions?.host ?? null,
        port: this.connectOptions?.port ?? null,
        health: null,
        food: null,
        position: { x: null, y: null, z: null },
        gameMode: null,
        version: null,
        players: [],
      };
    }

    if (this._reconnecting && !this.bot) {
      return {
        connected: false,
        reconnecting: true,
        reconnectAttempts: this._reconnectAttempts,
        username: this.connectOptions?.username ?? null,
        host: this.connectOptions?.host ?? null,
        port: this.connectOptions?.port ?? null,
        health: null,
        food: null,
        position: { x: null, y: null, z: null },
        gameMode: null,
        version: null,
        players: [],
      };
    }

    const pos = this.bot?.entity?.position;
    const players = Object.keys(this.bot?.players || {}).filter(
      (p) => p !== this.bot?.username,
    );

    return {
      connected: true,
      reconnecting: false,
      reconnectAttempts: this._reconnectAttempts,
      username: this.bot?.username ?? null,
      host: this.connectOptions?.host ?? null,
      port: this.connectOptions?.port ?? 25565,
      health: this.bot?.health ?? null,
      food: this.bot?.food ?? null,
      position: {
        x: pos ? Math.round(pos.x * 100) / 100 : null,
        y: pos ? Math.round(pos.y * 100) / 100 : null,
        z: pos ? Math.round(pos.z * 100) / 100 : null,
      },
      gameMode: this.bot?.game?.gameMode ?? null,
      version: this.bot?.version ?? null,
      players,
    };
  }

  getChatHistory(): ChatMessage[] {
    return [...this.chatHistory];
  }

  private addChatMessage(msg: ChatMessage) {
    this.chatHistory.push(msg);
    if (this.chatHistory.length > MAX_CHAT_HISTORY) {
      this.chatHistory.shift();
    }
    this.emit("chat", msg);
  }

  private scheduleReconnect() {
    if (this.manualDisconnect) return;
    if (!this.connectOptions?.autoReconnect) return;
    if (this._reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      logger.warn("Max reconnect attempts reached, giving up");
      this.addChatMessage({
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        text: `Max reconnect attempts (${MAX_RECONNECT_ATTEMPTS}) reached. Stopping.`,
        source: "system",
        username: null,
      });
      this._reconnecting = false;
      this.emit("status", this.getStatus());
      return;
    }

    this._reconnecting = true;
    this._reconnectAttempts++;
    this.emit("status", this.getStatus());

    const delay = RECONNECT_DELAY_MS;
    logger.info(
      { attempt: this._reconnectAttempts, delay },
      "Scheduling reconnect",
    );

    this.addChatMessage({
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      text: `Reconnecting in ${delay / 1000}s... (attempt ${this._reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})`,
      source: "system",
      username: null,
    });

    this.reconnectTimer = setTimeout(async () => {
      if (this.manualDisconnect || !this.connectOptions) return;
      logger.info({ attempt: this._reconnectAttempts }, "Attempting reconnect");
      try {
        await this.connect(this.connectOptions);
      } catch (err) {
        logger.error({ err }, "Reconnect attempt failed");
        this.addChatMessage({
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
          text: `Reconnect attempt ${this._reconnectAttempts} failed: ${err instanceof Error ? err.message : "Unknown error"}`,
          source: "system",
          username: null,
        });
        this.bot = null;
        this.scheduleReconnect();
      }
    }, delay);
  }

  connect(options: BotConnectOptions): Promise<BotStatus> {
    return new Promise((resolve, reject) => {
      if (this.bot) {
        this.cleanupBotOnly();
      }

      this.connectOptions = options;

      const botOptions: mineflayer.BotOptions = {
        host: options.host,
        port: options.port ?? 25565,
        username: options.username,
        auth: "offline",
      };

      if (options.version) {
        botOptions.version = options.version;
      }

      logger.info({ host: options.host, username: options.username }, "Connecting bot");

      let connected = false;

      try {
        this.bot = mineflayer.createBot(botOptions);
      } catch (err) {
        this.bot = null;
        reject(err);
        return;
      }

      const timeout = setTimeout(() => {
        if (!connected) {
          this.cleanupBotOnly();
          reject(new Error("Connection timed out after 30 seconds"));
        }
      }, 30000);

      this.bot.once("spawn", () => {
        connected = true;
        clearTimeout(timeout);
        this._reconnecting = false;
        logger.info({ username: this.bot?.username }, "Bot spawned");

        const isReconnect = this._reconnectAttempts > 0;
        this.addChatMessage({
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
          text: isReconnect
            ? `Reconnected as ${this.bot?.username} (attempt ${this._reconnectAttempts})`
            : `Bot connected as ${this.bot?.username} to ${options.host}:${options.port ?? 25565}`,
          source: "system",
          username: null,
        });

        this.setupBotListeners();
        this.emit("status", this.getStatus());

        if (options.startupCommands && options.startupCommands.length > 0) {
          this.runStartupCommands(options.startupCommands);
        }

        resolve(this.getStatus());
      });

      this.bot.once("error", (err) => {
        if (!connected) {
          clearTimeout(timeout);
          this.bot = null;
          reject(err);
        } else {
          logger.error({ err }, "Bot error after spawn");
          this.addChatMessage({
            id: crypto.randomUUID(),
            timestamp: new Date().toISOString(),
            text: `Bot error: ${err.message}`,
            source: "system",
            username: null,
          });
        }
      });

      this.bot.once("kicked", (reason) => {
        logger.warn({ reason }, "Bot was kicked");
        this.addChatMessage({
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
          text: `Bot was kicked: ${reason}`,
          source: "system",
          username: null,
        });
        this.emit("botEvent", { type: "kicked", data: { reason } });
        this.cleanupBotOnly();
        this.scheduleReconnect();
      });

      this.bot.once("end", (reason) => {
        logger.info({ reason }, "Bot connection ended");
        if (connected) {
          this.addChatMessage({
            id: crypto.randomUUID(),
            timestamp: new Date().toISOString(),
            text: `Bot disconnected: ${reason || "connection ended"}`,
            source: "system",
            username: null,
          });
        }
        this.emit("botEvent", { type: "end", data: { reason } });
        this.cleanupBotOnly();
        this.scheduleReconnect();
      });
    });
  }

  private setupBotListeners() {
    if (!this.bot) return;

    this.bot.on("chat", (username, message) => {
      const isBot = username === this.bot?.username;
      this.addChatMessage({
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        text: message,
        source: isBot ? "bot" : "player",
        username,
      });
    });

    this.bot.on("message", (jsonMsg) => {
      const text = jsonMsg.toString();
      if (text) {
        this.addChatMessage({
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
          text,
          source: "server",
          username: null,
        });
        this.emit("status", this.getStatus());
      }
    });

    this.bot.on("health", () => {
      this.emit("status", this.getStatus());
    });

    this.bot.on("move", () => {
      this.emit("status", this.getStatus());
    });

    this.bot.on("death", () => {
      logger.warn("Bot died");
      this.addChatMessage({
        id: crypto.randomUUID(),
        timestamp: new Date().toISOString(),
        text: "Bot died",
        source: "system",
        username: null,
      });
      this.emit("botEvent", { type: "death", data: {} });
    });

    this.bot.on("playerJoined", (player) => {
      this.emit("status", this.getStatus());
      this.emit("botEvent", { type: "playerJoined", data: { username: player.username } });
    });

    this.bot.on("playerLeft", (player) => {
      this.emit("status", this.getStatus());
      this.emit("botEvent", { type: "playerLeft", data: { username: player.username } });
    });
  }

  private runStartupCommands(commands: string[]) {
    commands.forEach((cmd, index) => {
      setTimeout(() => {
        if (!this.bot) return;
        const toSend = cmd.startsWith("/") ? cmd : `/${cmd}`;
        try {
          this.bot.chat(toSend);
          this.addChatMessage({
            id: crypto.randomUUID(),
            timestamp: new Date().toISOString(),
            text: toSend,
            source: "bot",
            username: this.bot.username,
          });
          logger.info({ command: toSend }, "Ran startup command");
        } catch (err) {
          logger.error({ err, command: toSend }, "Failed to run startup command");
        }
      }, 2000 + index * 1500);
    });
  }

  private cleanupBotOnly() {
    this.stopMovement();
    this.bot = null;
    this.emit("status", this.getStatus());
  }

  disconnect() {
    this.manualDisconnect = true;
    this._reconnecting = false;
    this._reconnectAttempts = 0;

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (!this.bot) {
      this.connectOptions = null;
      this.emit("status", this.getStatus());
      return;
    }

    this.stopMovement();
    logger.info("Disconnecting bot");
    try {
      this.bot.quit("Disconnected from web panel");
    } catch (_e) {
      // ignore
    }
    this.bot = null;
    this.connectOptions = null;
    this.emit("status", this.getStatus());

    // Reset for next fresh connection
    this.manualDisconnect = false;
  }

  getInventory() {
    if (!this.bot) throw new Error("Bot is not connected");

    const toItem = (item: any, slotOverride?: number) => {
      if (!item) return null;
      return {
        slot: slotOverride ?? item.slot,
        name: item.name,
        displayName: item.displayName || item.name,
        count: item.count,
        type: item.type,
        durabilityUsed: item.durabilityUsed ?? null,
        maxDurability: item.maxDurability ?? null,
      };
    };

    // main inventory slots 9–35, hotbar 36–44
    const allSlots = this.bot.inventory.slots;
    const items = allSlots
      .slice(9, 36)
      .map((item, i) => (item ? toItem(item, i + 9) : null))
      .filter(Boolean) as ReturnType<typeof toItem>[];

    const hotbar: (ReturnType<typeof toItem>)[] = Array.from({ length: 9 }, (_, i) => {
      const item = allSlots[36 + i];
      return item ? toItem(item, 36 + i) : null;
    });

    const equipment = {
      hand: toItem(this.bot.inventory.slots[36 + this.bot.quickBarSlot], 36 + this.bot.quickBarSlot),
      offhand: toItem(allSlots[45], 45),
      head: toItem(allSlots[5], 5),
      chest: toItem(allSlots[6], 6),
      legs: toItem(allSlots[7], 7),
      feet: toItem(allSlots[8], 8),
    };

    return {
      items,
      hotbar,
      selectedHotbarSlot: this.bot.quickBarSlot,
      equipment,
    };
  }

  async equipItem(slot: number, destination: string): Promise<void> {
    if (!this.bot) throw new Error("Bot is not connected");
    const item = this.bot.inventory.slots[slot];
    if (!item) throw new Error(`No item in slot ${slot}`);

    const destMap: Record<string, Parameters<typeof this.bot.equip>[1]> = {
      hand: "hand",
      "off-hand": "off-hand",
      head: "head",
      torso: "torso",
      legs: "legs",
      feet: "feet",
    };

    const dest = destMap[destination];
    if (!dest) throw new Error(`Unknown destination: ${destination}`);
    await this.bot.equip(item, dest);
    this.emit("inventory", this.getInventory());
  }

  async dropItem(slot: number, count?: number): Promise<void> {
    if (!this.bot) throw new Error("Bot is not connected");
    const item = this.bot.inventory.slots[slot];
    if (!item) throw new Error(`No item in slot ${slot}`);
    const dropCount = count ?? item.count;
    await this.bot.toss(item.type, null, dropCount);
    this.emit("inventory", this.getInventory());
  }

  selectHotbar(hotbarSlot: number): void {
    if (!this.bot) throw new Error("Bot is not connected");
    if (hotbarSlot < 0 || hotbarSlot > 8) throw new Error("hotbarSlot must be 0-8");
    this.bot.setQuickBarSlot(hotbarSlot);
    this.emit("inventory", this.getInventory());
  }

  sendChat(message: string): void {
    if (!this.bot) throw new Error("Bot is not connected");
    this.bot.chat(message);
    this.addChatMessage({
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      text: message,
      source: "bot",
      username: this.bot.username,
    });
  }

  executeCommand(command: string): void {
    if (!this.bot) throw new Error("Bot is not connected");
    this.bot.chat(command.startsWith("/") ? command : `/${command}`);
  }

  move(action: string, duration?: number): void {
    if (!this.bot) throw new Error("Bot is not connected");

    this.stopMovement();

    const controlMap: Record<string, string> = {
      forward: "forward",
      back: "back",
      left: "left",
      right: "right",
      jump: "jump",
      sprint: "sprint",
      sneak: "sneak",
    };

    if (action === "stop") return;

    if (action === "attack") {
      const nearest = this.bot.nearestEntity();
      if (nearest) this.bot.attack(nearest);
      return;
    }

    if (action === "use") {
      this.bot.activateItem();
      return;
    }

    const control = controlMap[action];
    if (!control) throw new Error(`Unknown action: ${action}`);

    this.bot.setControlState(control as Parameters<typeof this.bot.setControlState>[0], true);
    this.currentAction = action;

    if (duration) {
      setTimeout(() => {
        this.stopMovement();
      }, duration);
    }
  }

  stopMovement() {
    if (this.movementInterval) {
      clearInterval(this.movementInterval);
      this.movementInterval = null;
    }
    if (this.bot && this.currentAction) {
      const controlMap: Record<string, string> = {
        forward: "forward",
        back: "back",
        left: "left",
        right: "right",
        jump: "jump",
        sprint: "sprint",
        sneak: "sneak",
      };
      const control = controlMap[this.currentAction];
      if (control) {
        try {
          this.bot.setControlState(control as Parameters<typeof this.bot.setControlState>[0], false);
        } catch (_e) {
          // ignore
        }
      }
      this.currentAction = null;
    }
  }
}

export const botManager = new BotManager();
