import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import app from "./app";
import { logger } from "./lib/logger";
import { botManager } from "./lib/bot-manager";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const httpServer = createServer(app);

const io = new SocketIOServer(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
  path: "/socket.io",
});

io.on("connection", (socket) => {
  logger.info({ socketId: socket.id }, "Client connected via WebSocket");

  socket.emit("status", botManager.getStatus());
  socket.emit("chatHistory", botManager.getChatHistory());

  socket.on("disconnect", () => {
    logger.info({ socketId: socket.id }, "Client disconnected");
  });
});

botManager.on("chat", (msg) => {
  io.emit("chat", msg);
});

botManager.on("status", (status) => {
  io.emit("status", status);
});

botManager.on("botEvent", (event) => {
  io.emit("botEvent", event);
});

botManager.on("inventory", (inventory) => {
  io.emit("inventory", inventory);
});

httpServer.listen(port, (err?: Error) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
