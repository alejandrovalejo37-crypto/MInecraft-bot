import { useEffect, useRef, useState } from "react";
import { 
  useGetBotStatus, 
  getGetBotStatusQueryKey,
  useConnectBot,
  useDisconnectBot,
  useSendChat,
  useMoveBot,
  useGetChatHistory,
  getGetChatHistoryQueryKey,
  useExecuteCommand
} from "@workspace/api-client-react";
import InventoryPanel from "@/components/inventory-panel";
import { useSocketIntegration } from "@/lib/socket";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Heart, Drumstick, Activity, Send, TerminalSquare, AlertCircle, PowerOff, Compass, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, CornerRightUp, Sword, Hand, RefreshCw } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const connectSchema = z.object({
  host: z.string().min(1, "Server IP is required"),
  port: z.coerce.number().optional().default(25565),
  username: z.string().min(1, "Username is required"),
  version: z.string().optional(),
  startupCommands: z.string().optional(),
  autoReconnect: z.boolean().default(true),
});

export default function Dashboard() {
  const { isConnected: socketConnected } = useSocketIntegration();
  
  const { data: status, isLoading: statusLoading } = useGetBotStatus({
    query: {
      queryKey: getGetBotStatusQueryKey(),
      refetchInterval: 2000,
    }
  });

  const { data: chatHistory } = useGetChatHistory({
    query: {
      queryKey: getGetChatHistoryQueryKey(),
      refetchInterval: 5000,
    }
  });

  const connectBot = useConnectBot();
  const disconnectBot = useDisconnectBot();
  const sendChat = useSendChat();
  const executeCommand = useExecuteCommand();

  const isConnected = status?.connected || false;

  const [chatInput, setChatInput] = useState("");
  const chatScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    
    if (chatInput.startsWith("/")) {
      executeCommand.mutate({ data: { command: chatInput.substring(1) } });
    } else {
      sendChat.mutate({ data: { message: chatInput } });
    }
    setChatInput("");
  };

  const handleDisconnect = () => {
    disconnectBot.mutate(undefined, {
      onSuccess: () => {
        toast.success("Disconnected from server");
      }
    });
  };

  if (statusLoading && !status) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-4 text-primary animate-pulse">
          <TerminalSquare className="w-12 h-12" />
          <h2 className="text-xl font-bold tracking-widest">INITIALIZING HUD...</h2>
        </div>
      </div>
    );
  }

  const isReconnecting = status?.reconnecting ?? false;

  if (!isConnected && !isReconnecting) {
    return <ConnectForm isPending={connectBot.isPending} onSubmit={(data) => {
      const { startupCommands: rawCmds, autoReconnect, ...rest } = data;
      const startupCommands = rawCmds
        ? rawCmds.split("\n").map((s: string) => s.trim()).filter((s: string) => s.length > 0)
        : [];
      connectBot.mutate({ data: { ...rest, startupCommands, autoReconnect } }, {
        onSuccess: () => toast.success("Bot connected successfully!"),
        onError: (err) => toast.error(`Connection failed: ${err.message}`)
      });
    }} />;
  }

  if (!isConnected && isReconnecting) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-6 text-primary">
          <TerminalSquare className="w-14 h-14 animate-pulse" />
          <div className="text-center">
            <h2 className="text-2xl font-bold tracking-widest uppercase">Reconnecting...</h2>
            <p className="text-primary/60 text-sm mt-2 font-mono">
              {status?.host}:{status?.port} — attempt {status?.reconnectAttempts}
            </p>
          </div>
          <div className="flex gap-1 mt-2">
            {[0,1,2].map(i => (
              <span key={i} className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
            ))}
          </div>
          <Button
            variant="outline"
            className="rounded-none border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground uppercase tracking-wider mt-4"
            onClick={handleDisconnect}
          >
            <PowerOff className="w-4 h-4 mr-2" />
            Cancel Reconnect
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen max-h-screen p-4 gap-4 overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border pb-4 shrink-0">
        <div className="flex items-center gap-4">
          <TerminalSquare className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-2xl font-bold uppercase tracking-wider text-primary">BOT_CTRL // {status.username}</h1>
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 rounded-none bg-primary animate-pulse shadow-[0_0_8px_currentColor]" />
              <span className="text-primary/80">LINK ESTABLISHED :: {status.host}:{status.port}</span>
              <span className="text-muted-foreground ml-4">VERSION: {status.version || "UNKNOWN"}</span>
            </div>
          </div>
        </div>
        <Button 
          variant="destructive" 
          onClick={handleDisconnect}
          disabled={disconnectBot.isPending}
          className="uppercase tracking-wider font-bold"
        >
          <PowerOff className="w-4 h-4 mr-2" />
          Terminate Link
        </Button>
      </header>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 min-h-0">
        
        {/* Left Column: Status & Movement */}
        <div className="flex flex-col gap-4 lg:col-span-3 overflow-y-auto pr-2">
          {/* Status Panel */}
          <Card className="rounded-none border-2">
            <CardHeader className="border-b border-border pb-3">
              <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-widest">
                <Activity className="w-4 h-4" />
                Vitals
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 flex flex-col gap-4">
              {/* Health */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-destructive font-bold">HEALTH</span>
                  <span>{status.health ?? 0} / 20</span>
                </div>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => {
                    const health = status.health ?? 0;
                    const filled = health >= (i + 1) * 2;
                    const half = health === (i * 2) + 1;
                    return (
                      <Heart 
                        key={i} 
                        className={`w-5 h-5 ${filled || half ? "text-destructive fill-destructive" : "text-muted-foreground"}`} 
                      />
                    );
                  })}
                </div>
              </div>

              {/* Food */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-orange-500 font-bold">SATURATION</span>
                  <span>{status.food ?? 0} / 20</span>
                </div>
                <div className="flex gap-1">
                  {Array.from({ length: 10 }).map((_, i) => {
                    const food = status.food ?? 0;
                    const filled = food >= (i + 1) * 2;
                    const half = food === (i * 2) + 1;
                    return (
                      <Drumstick 
                        key={i} 
                        className={`w-5 h-5 ${filled || half ? "text-orange-500 fill-orange-500" : "text-muted-foreground"}`} 
                      />
                    );
                  })}
                </div>
              </div>

              {/* Position */}
              <div className="mt-2 bg-secondary/50 p-3 border border-border">
                <div className="text-xs text-muted-foreground mb-2 flex items-center gap-2">
                  <Compass className="w-4 h-4" />
                  COORDINATES
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-background p-2 border border-border">
                    <span className="block text-[10px] text-muted-foreground">X</span>
                    <span className="font-bold">{status.position?.x?.toFixed(1) ?? "---"}</span>
                  </div>
                  <div className="bg-background p-2 border border-border">
                    <span className="block text-[10px] text-muted-foreground">Y</span>
                    <span className="font-bold">{status.position?.y?.toFixed(1) ?? "---"}</span>
                  </div>
                  <div className="bg-background p-2 border border-border">
                    <span className="block text-[10px] text-muted-foreground">Z</span>
                    <span className="font-bold">{status.position?.z?.toFixed(1) ?? "---"}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Movement Panel */}
          <MovementPanel />

          {/* Quick Actions */}
          <Card className="rounded-none border-2">
            <CardHeader className="border-b border-border pb-3">
              <CardTitle className="text-sm uppercase tracking-widest">Quick Macros</CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="grid grid-cols-2 gap-2">
                <Button 
                  variant="outline" 
                  className="rounded-none justify-start border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={() => executeCommand.mutate({ data: { command: "spawn" } })}
                >
                  /spawn
                </Button>
                <Button 
                  variant="outline" 
                  className="rounded-none justify-start border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={() => executeCommand.mutate({ data: { command: "home" } })}
                >
                  /home
                </Button>
                <Button 
                  variant="outline" 
                  className="rounded-none justify-start border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={() => sendChat.mutate({ data: { message: "Hello server!" } })}
                >
                  Greet
                </Button>
                <Button 
                  variant="outline" 
                  className="rounded-none justify-start border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground"
                  onClick={() => executeCommand.mutate({ data: { command: "ping" } })}
                >
                  /ping
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Middle Column: Chat / Log */}
        <Card className="flex flex-col rounded-none border-2 lg:col-span-5 overflow-hidden">
          <CardHeader className="border-b border-border bg-secondary/20 pb-3 shrink-0">
            <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-widest">
              <TerminalSquare className="w-4 h-4" />
              Terminal Uplink
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 overflow-hidden p-0 relative">
            <div 
              ref={chatScrollRef}
              className="absolute inset-0 overflow-y-auto p-4 flex flex-col gap-1 text-sm font-mono"
            >
              {chatHistory?.length === 0 && (
                <div className="text-muted-foreground italic">No uplink history...</div>
              )}
              {chatHistory?.map((msg) => (
                <div key={msg.id} className="group hover:bg-secondary/30 px-2 py-0.5 flex gap-3 break-words">
                  <span className="text-muted-foreground shrink-0 select-none">
                    [{new Date(msg.timestamp).toLocaleTimeString()}]
                  </span>
                  {msg.source === "system" && (
                    <span className="text-primary italic shrink-0">SYS:</span>
                  )}
                  {msg.source === "bot" && (
                    <span className="text-accent-foreground bg-primary px-1 shrink-0 font-bold">BOT:</span>
                  )}
                  {msg.source === "player" && msg.username && (
                    <span className="text-blue-400 shrink-0 font-bold"><span className="text-muted-foreground">{"<"}</span>{msg.username}<span className="text-muted-foreground">{">"}</span></span>
                  )}
                  {msg.source === "server" && (
                    <span className="text-yellow-500 shrink-0 font-bold">[SERVER]:</span>
                  )}
                  <span className={`flex-1 ${msg.source === 'system' ? 'text-primary/70' : 'text-foreground'}`}>
                    {msg.text}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="border-t border-border p-3 bg-secondary/10 shrink-0">
            <form onSubmit={handleSendChat} className="flex w-full gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-primary font-bold">{">"}</span>
                <Input 
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Transmit message or /command..."
                  className="rounded-none border-primary/50 bg-background/50 pl-8 focus-visible:ring-primary placeholder:text-primary/30 text-primary font-bold"
                />
              </div>
              <Button type="submit" className="rounded-none uppercase tracking-widest font-bold px-6" disabled={!chatInput.trim()}>
                <Send className="w-4 h-4 mr-2" />
                Tx
              </Button>
            </form>
          </CardFooter>
        </Card>

        {/* Right Column: Inventory + Players (tabs) */}
        <div className="lg:col-span-4 flex flex-col min-h-0 hidden lg:flex">
          <Tabs defaultValue="inventory" className="flex flex-col flex-1 min-h-0">
            <TabsList className="rounded-none border border-border bg-secondary/20 w-full shrink-0">
              <TabsTrigger value="inventory" className="flex-1 rounded-none uppercase tracking-wider text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Inventory
              </TabsTrigger>
              <TabsTrigger value="players" className="flex-1 rounded-none uppercase tracking-wider text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Network
                <span className="ml-1 bg-primary/20 text-primary px-1 text-[10px] data-[state=active]:bg-primary-foreground/20">
                  {status.players?.length ?? 0}
                </span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="inventory" className="flex-1 overflow-y-auto mt-0 pt-2">
              <InventoryPanel />
            </TabsContent>

            <TabsContent value="players" className="flex-1 overflow-y-auto mt-0 pt-2">
              <Card className="rounded-none border-2">
                <CardHeader className="border-b border-border pb-3 shrink-0">
                  <CardTitle className="text-sm uppercase tracking-widest flex justify-between items-center">
                    Network
                    <span className="bg-primary/20 text-primary px-2 py-0.5 text-xs">{status.players?.length ?? 0}</span>
                  </CardTitle>
                </CardHeader>
                <ScrollArea className="flex-1">
                  <div className="p-4 flex flex-col gap-2">
                    {status.players?.length === 0 && (
                      <div className="text-muted-foreground text-sm">No other units detected.</div>
                    )}
                    {status.players?.map((player, idx) => (
                      <div key={idx} className="flex items-center gap-2 p-2 border border-border bg-secondary/20 text-sm">
                        <div className="w-2 h-2 rounded-full bg-primary" />
                        <span className="font-bold truncate">{player}</span>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

      </div>
    </div>
  );
}

function MovementPanel() {
  const moveBot = useMoveBot();

  const handleAction = (action: "forward"|"back"|"left"|"right"|"jump"|"stop"|"sprint"|"sneak"|"attack"|"use", duration?: number) => {
    moveBot.mutate({ data: { action, duration } });
  };

  const handleStartMove = (action: "forward"|"back"|"left"|"right"|"sneak"|"sprint") => {
    moveBot.mutate({ data: { action } });
  };

  const handleStopMove = (action: "forward"|"back"|"left"|"right"|"sneak"|"sprint") => {
    // Send stop for the specific action if backend supports it, otherwise generic stop
    // Or we send the action again to toggle it off? The API says action: "stop"
    moveBot.mutate({ data: { action: "stop" } });
  };

  return (
    <Card className="rounded-none border-2">
      <CardHeader className="border-b border-border pb-3">
        <CardTitle className="text-sm uppercase tracking-widest flex justify-between items-center">
          Nav System
          <span className="text-[10px] text-muted-foreground">HOLD TO ENGAGE</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 flex flex-col items-center gap-4">
        
        {/* WASD Layout */}
        <div className="grid grid-cols-3 gap-2 w-full max-w-[200px]">
          <div />
          <Button 
            variant="outline" 
            className="rounded-none h-12 bg-secondary border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground active:scale-95 transition-transform"
            onPointerDown={() => handleStartMove("forward")}
            onPointerUp={() => handleStopMove("forward")}
            onPointerLeave={() => handleStopMove("forward")}
          >
            <ArrowUp className="w-6 h-6" />
          </Button>
          <div />
          
          <Button 
            variant="outline" 
            className="rounded-none h-12 bg-secondary border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground active:scale-95 transition-transform"
            onPointerDown={() => handleStartMove("left")}
            onPointerUp={() => handleStopMove("left")}
            onPointerLeave={() => handleStopMove("left")}
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <Button 
            variant="outline" 
            className="rounded-none h-12 bg-secondary border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground active:scale-95 transition-transform"
            onPointerDown={() => handleStartMove("back")}
            onPointerUp={() => handleStopMove("back")}
            onPointerLeave={() => handleStopMove("back")}
          >
            <ArrowDown className="w-6 h-6" />
          </Button>
          <Button 
            variant="outline" 
            className="rounded-none h-12 bg-secondary border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground active:scale-95 transition-transform"
            onPointerDown={() => handleStartMove("right")}
            onPointerUp={() => handleStopMove("right")}
            onPointerLeave={() => handleStopMove("right")}
          >
            <ArrowRight className="w-6 h-6" />
          </Button>
        </div>

        {/* Actions Layout */}
        <div className="grid grid-cols-2 gap-2 w-full mt-2">
          <Button 
            variant="outline" 
            className="rounded-none border-primary/30 text-primary/70 hover:bg-primary/20"
            onClick={() => handleAction("jump", 100)} // short jump
          >
            <CornerRightUp className="w-4 h-4 mr-2" />
            JUMP
          </Button>
          <Button 
            variant="outline" 
            className="rounded-none border-primary/30 text-primary/70 hover:bg-primary/20"
            onPointerDown={() => handleStartMove("sneak")}
            onPointerUp={() => handleStopMove("sneak")}
            onPointerLeave={() => handleStopMove("sneak")}
          >
            SNEAK
          </Button>
          <Button 
            variant="outline" 
            className="rounded-none border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground"
            onClick={() => handleAction("attack")}
          >
            <Sword className="w-4 h-4 mr-2" />
            ATTACK
          </Button>
          <Button 
            variant="outline" 
            className="rounded-none border-blue-500/50 text-blue-500 hover:bg-blue-500 hover:text-black"
            onClick={() => handleAction("use")}
          >
            <Hand className="w-4 h-4 mr-2" />
            USE
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ConnectForm({ isPending, onSubmit }: { isPending: boolean, onSubmit: (data: any) => void }) {
  const form = useForm<z.infer<typeof connectSchema>>({
    resolver: zodResolver(connectSchema),
    defaultValues: {
      host: "localhost",
      port: 25565,
      username: "Bot_01",
      version: "",
      startupCommands: "/login mava1212\n/survival",
      autoReconnect: true,
    }
  });

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-[url('https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
      <div className="absolute inset-0 bg-background/90 backdrop-blur-sm z-0" />
      
      <Card className="w-full max-w-md relative z-10 rounded-none border-primary/50 shadow-[0_0_30px_rgba(0,255,0,0.1)]">
        <CardHeader className="border-b border-primary/20 pb-6 text-center">
          <TerminalSquare className="w-12 h-12 mx-auto mb-4 text-primary" />
          <CardTitle className="text-2xl font-bold uppercase tracking-widest text-primary">Initialize Uplink</CardTitle>
          <p className="text-primary/60 text-sm mt-2">Minecraft Bot Controller Terminal</p>
        </CardHeader>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="host"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary uppercase tracking-wider text-xs">Target Host</FormLabel>
                    <FormControl>
                      <Input placeholder="mc.server.net" className="rounded-none border-primary/50 bg-background focus-visible:ring-primary text-primary font-bold" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="port"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-primary uppercase tracking-wider text-xs">Port</FormLabel>
                      <FormControl>
                        <Input type="number" className="rounded-none border-primary/50 bg-background focus-visible:ring-primary text-primary font-bold" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="version"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-primary uppercase tracking-wider text-xs">Version</FormLabel>
                      <FormControl>
                        <Input placeholder="auto-detect" className="rounded-none border-primary/50 bg-background focus-visible:ring-primary text-primary font-bold" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary uppercase tracking-wider text-xs">Bot Callsign</FormLabel>
                    <FormControl>
                      <Input placeholder="Bot_01" className="rounded-none border-primary/50 bg-background focus-visible:ring-primary text-primary font-bold" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="startupCommands"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-primary uppercase tracking-wider text-xs">Startup Commands <span className="text-muted-foreground normal-case">(one per line, runs on join)</span></FormLabel>
                    <FormControl>
                      <Textarea
                        rows={3}
                        placeholder={"/login password\n/survival"}
                        className="rounded-none border-primary/50 bg-background focus-visible:ring-primary text-primary font-mono text-sm resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="autoReconnect"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center justify-between p-3 border border-primary/30 bg-secondary/20">
                      <div>
                        <FormLabel className="text-primary uppercase tracking-wider text-xs flex items-center gap-2">
                          <RefreshCw className="w-3 h-3" />
                          Auto-Reconnect
                        </FormLabel>
                        <p className="text-muted-foreground text-[10px] mt-0.5">Reconnect automatically if connection drops</p>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="data-[state=checked]:bg-primary"
                        />
                      </FormControl>
                    </div>
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full mt-6 rounded-none uppercase tracking-widest font-bold h-12"
                disabled={isPending}
              >
                {isPending ? (
                  <span className="flex items-center gap-2">
                    <Activity className="w-4 h-4 animate-spin" />
                    Connecting...
                  </span>
                ) : (
                  "Establish Connection"
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
