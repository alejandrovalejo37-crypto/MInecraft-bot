import { io, Socket } from "socket.io-client";
import { useEffect, useState } from "react";
import type { BotStatus, ChatMessage, InventoryData } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  getGetBotStatusQueryKey,
  getGetChatHistoryQueryKey,
  getGetInventoryQueryKey,
} from "@workspace/api-client-react";

let socketInstance: Socket | null = null;

export function getSocket() {
  if (!socketInstance) {
    socketInstance = io("/", { path: "/socket.io", autoConnect: false });
  }
  return socketInstance;
}

export function useSocketIntegration() {
  const [isConnected, setIsConnected] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const socket = getSocket();
    socket.connect();

    const onConnect = () => setIsConnected(true);
    const onDisconnect = () => setIsConnected(false);

    const onStatus = (status: BotStatus) => {
      queryClient.setQueryData(getGetBotStatusQueryKey(), status);
    };

    const onChat = (message: ChatMessage) => {
      queryClient.setQueryData(getGetChatHistoryQueryKey(), (old: ChatMessage[] | undefined) => {
        if (!old) return [message];
        return [...old, message].slice(-200);
      });
    };

    const onInventory = (inventory: InventoryData) => {
      queryClient.setQueryData(getGetInventoryQueryKey(), inventory);
    };

    const onBotEvent = (_event: { type: string; data: unknown }) => {
      // handled via status updates
    };

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("status", onStatus);
    socket.on("chat", onChat);
    socket.on("inventory", onInventory);
    socket.on("botEvent", onBotEvent);

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("status", onStatus);
      socket.off("chat", onChat);
      socket.off("inventory", onInventory);
      socket.off("botEvent", onBotEvent);
    };
  }, [queryClient]);

  return { isConnected };
}
