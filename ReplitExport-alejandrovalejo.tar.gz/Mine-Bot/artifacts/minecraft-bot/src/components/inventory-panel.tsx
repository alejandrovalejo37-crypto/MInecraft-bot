import { useState } from "react";
import {
  useGetInventory,
  getGetInventoryQueryKey,
  useEquipItem,
  useDropItem,
  useSelectHotbar,
} from "@workspace/api-client-react";
import type { InventoryItem, EquipInputDestination } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, Shield, Sword, HandMetal, ChevronDown, Trash2, Zap } from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";

const EQUIP_DESTINATIONS: { label: string; value: EquipInputDestination }[] = [
  { label: "Main Hand", value: "hand" },
  { label: "Off Hand", value: "off-hand" },
  { label: "Helmet", value: "head" },
  { label: "Chestplate", value: "torso" },
  { label: "Leggings", value: "legs" },
  { label: "Boots", value: "feet" },
];

function ItemCell({
  item,
  isSelected,
  onClick,
}: {
  item: InventoryItem | null | undefined;
  isSelected?: boolean;
  onClick?: () => void;
}) {
  if (!item) {
    return (
      <div
        className={`w-full aspect-square border border-border bg-secondary/20 flex items-center justify-center cursor-default ${isSelected ? "border-primary shadow-[0_0_6px_currentColor]" : ""}`}
      />
    );
  }

  const hasDurability =
    item.durabilityUsed != null && item.maxDurability != null && item.maxDurability > 0;
  const durabilityPct = hasDurability
    ? Math.max(0, 1 - item.durabilityUsed! / item.maxDurability!)
    : null;

  return (
    <button
      onClick={onClick}
      title={`${item.displayName} ×${item.count}${hasDurability ? ` (${Math.round(durabilityPct! * 100)}% durability)` : ""}`}
      className={`w-full aspect-square border relative flex flex-col items-center justify-center text-center bg-secondary/30 hover:bg-primary/20 hover:border-primary transition-colors cursor-pointer ${
        isSelected ? "border-primary shadow-[0_0_8px_rgba(0,255,0,0.4)] bg-primary/10" : "border-border"
      }`}
    >
      <span className="text-[10px] font-mono text-foreground/80 leading-tight px-0.5 break-words line-clamp-2">
        {item.displayName}
      </span>
      {item.count > 1 && (
        <span className="absolute bottom-0 right-0.5 text-[9px] font-bold text-primary">
          {item.count}
        </span>
      )}
      {durabilityPct !== null && (
        <div className="absolute bottom-0 left-0 right-0 h-0.5">
          <div
            className="h-full"
            style={{
              width: `${durabilityPct * 100}%`,
              backgroundColor: durabilityPct > 0.5 ? "#22c55e" : durabilityPct > 0.2 ? "#f59e0b" : "#ef4444",
            }}
          />
        </div>
      )}
    </button>
  );
}

function EquipmentSlot({
  label,
  item,
  onSelect,
}: {
  label: string;
  item: InventoryItem | null | undefined;
  onSelect: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-1">
      <span className="text-[9px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <div className="w-10 h-10">
        <ItemCell item={item} onClick={item ? onSelect : undefined} />
      </div>
    </div>
  );
}

export default function InventoryPanel() {
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);

  const { data: inventory, isLoading } = useGetInventory({
    query: {
      queryKey: getGetInventoryQueryKey(),
      refetchInterval: 3000,
      retry: false,
    },
  });

  const equipItem = useEquipItem();
  const dropItem = useDropItem();
  const selectHotbar = useSelectHotbar();

  const handleEquip = (destination: EquipInputDestination) => {
    if (!selectedItem) return;
    equipItem.mutate(
      { data: { slot: selectedItem.slot, destination } },
      {
        onSuccess: () => {
          toast.success(`Equipped ${selectedItem.displayName} to ${destination}`);
          setSelectedItem(null);
        },
        onError: (err) => toast.error(`Equip failed: ${err.message}`),
      }
    );
  };

  const handleDrop = (count?: number) => {
    if (!selectedItem) return;
    dropItem.mutate(
      { data: { slot: selectedItem.slot, count } },
      {
        onSuccess: () => {
          toast.success(`Dropped ${count ?? selectedItem.count}× ${selectedItem.displayName}`);
          setSelectedItem(null);
        },
        onError: (err) => toast.error(`Drop failed: ${err.message}`),
      }
    );
  };

  const handleHotbarSelect = (hotbarSlot: number) => {
    selectHotbar.mutate(
      { data: { hotbarSlot } },
      {
        onSuccess: () => toast.success(`Selected hotbar slot ${hotbarSlot + 1}`),
        onError: (err) => toast.error(`Failed: ${err.message}`),
      }
    );
  };

  if (isLoading) {
    return (
      <Card className="rounded-none border-2">
        <CardContent className="py-8 flex items-center justify-center">
          <span className="text-muted-foreground text-sm animate-pulse">Loading inventory...</span>
        </CardContent>
      </Card>
    );
  }

  if (!inventory) {
    return (
      <Card className="rounded-none border-2">
        <CardContent className="py-8 flex items-center justify-center">
          <span className="text-muted-foreground text-sm">Inventory unavailable</span>
        </CardContent>
      </Card>
    );
  }

  // Build 3×9 main inventory grid (slots 9–35)
  const mainGrid: (InventoryItem | null)[] = Array.from({ length: 27 }, (_, i) => {
    const slot = i + 9;
    return inventory.items?.find((it) => it.slot === slot) ?? null;
  });

  return (
    <Card className="rounded-none border-2">
      <CardHeader className="border-b border-border pb-3">
        <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-widest">
          <Package className="w-4 h-4" />
          Inventory
          <Badge variant="secondary" className="ml-auto text-xs font-mono">
            {inventory.items?.length ?? 0}/27
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="pt-4 flex flex-col gap-4">
        {/* Selected Item Actions */}
        {selectedItem && (
          <div className="border border-primary/50 bg-primary/5 p-3 flex items-center justify-between gap-2">
            <div className="flex-1 min-w-0">
              <p className="text-primary font-bold text-sm truncate">{selectedItem.displayName}</p>
              <p className="text-xs text-muted-foreground">Slot {selectedItem.slot} · ×{selectedItem.count}</p>
            </div>
            <div className="flex gap-1 shrink-0">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-none border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground h-7 px-2 text-xs"
                    disabled={equipItem.isPending}
                  >
                    <Zap className="w-3 h-3 mr-1" />
                    Equip
                    <ChevronDown className="w-3 h-3 ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="rounded-none">
                  <DropdownMenuLabel className="text-xs uppercase tracking-wider text-muted-foreground">Destination</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {EQUIP_DESTINATIONS.map((d) => (
                    <DropdownMenuItem
                      key={d.value}
                      className="font-mono text-xs cursor-pointer"
                      onClick={() => handleEquip(d.value)}
                    >
                      {d.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-none border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground h-7 px-2 text-xs"
                    disabled={dropItem.isPending}
                  >
                    <Trash2 className="w-3 h-3 mr-1" />
                    Drop
                    <ChevronDown className="w-3 h-3 ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="rounded-none">
                  <DropdownMenuItem className="text-xs cursor-pointer" onClick={() => handleDrop()}>
                    Drop all ({selectedItem.count})
                  </DropdownMenuItem>
                  {selectedItem.count > 1 && (
                    <DropdownMenuItem className="text-xs cursor-pointer" onClick={() => handleDrop(1)}>
                      Drop 1
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                size="sm"
                variant="ghost"
                className="rounded-none h-7 px-2 text-xs"
                onClick={() => setSelectedItem(null)}
              >
                ✕
              </Button>
            </div>
          </div>
        )}

        {/* Equipment slots */}
        <div>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
            <Shield className="w-3 h-3" /> Equipment
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <EquipmentSlot label="Head" item={inventory.equipment?.head} onSelect={() => setSelectedItem(inventory.equipment?.head ?? null)} />
            <EquipmentSlot label="Chest" item={inventory.equipment?.chest} onSelect={() => setSelectedItem(inventory.equipment?.chest ?? null)} />
            <EquipmentSlot label="Legs" item={inventory.equipment?.legs} onSelect={() => setSelectedItem(inventory.equipment?.legs ?? null)} />
            <EquipmentSlot label="Feet" item={inventory.equipment?.feet} onSelect={() => setSelectedItem(inventory.equipment?.feet ?? null)} />
            <EquipmentSlot label="Hand" item={inventory.equipment?.hand} onSelect={() => setSelectedItem(inventory.equipment?.hand ?? null)} />
            <EquipmentSlot label="Offhand" item={inventory.equipment?.offhand} onSelect={() => setSelectedItem(inventory.equipment?.offhand ?? null)} />
          </div>
        </div>

        {/* Hotbar */}
        <div>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
            <Sword className="w-3 h-3" /> Hotbar
          </p>
          <div className="grid grid-cols-9 gap-0.5">
            {Array.from({ length: 9 }, (_, i) => {
              const item = inventory.hotbar?.[i] ?? null;
              const isSelected = inventory.selectedHotbarSlot === i;
              return (
                <div key={i} className="flex flex-col items-center gap-0.5">
                  <ItemCell
                    item={item}
                    isSelected={isSelected}
                    onClick={() => {
                      handleHotbarSelect(i);
                      if (item) setSelectedItem(item);
                    }}
                  />
                  <span className={`text-[8px] font-mono ${isSelected ? "text-primary font-bold" : "text-muted-foreground"}`}>
                    {i + 1}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Main Inventory 3×9 grid */}
        <div>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
            <HandMetal className="w-3 h-3" /> Backpack
          </p>
          <div className="grid grid-cols-9 gap-0.5">
            {mainGrid.map((item, i) => (
              <ItemCell
                key={i}
                item={item}
                isSelected={selectedItem?.slot === (i + 9)}
                onClick={item ? () => setSelectedItem(item) : undefined}
              />
            ))}
          </div>
        </div>

        {inventory.items?.length === 0 && (
          <p className="text-center text-muted-foreground text-xs py-2">Inventory is empty</p>
        )}
      </CardContent>
    </Card>
  );
}
